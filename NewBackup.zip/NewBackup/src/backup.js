import React, { useState, useEffect } from 'react';
import Editor from 'react-simple-code-editor';

import { highlight, languages } from 'prismjs/components/prism-core';
import 'prismjs/components/prism-clike';
import 'prismjs/components/prism-javascript';
// import Editor from '././Editor';
import './prism-vsc-dark-plus.css';
import './editor.css';
// import './slider.css';
// import Slider from './Slider';

const codeSnippet = ``;

function Editors() {
  const [code, setCode] = useState(codeSnippet);
  const [selection, setSelection] = useState(codeSnippet);
  const [count, setCount] = useState(0);
  const startingPoint = 0;

  const getInputSelection = (elem) => {
    if (typeof elem != "undefined") {
      let s = elem[0].selectionStart;
      let e = elem[0].selectionEnd;
      return elem.val().substring(s, e);
    }
    else {
      return '';
    }
  }

  const handleClick = (e) => {
    let selectionContents = document.getSelection().toString();
    setSelection(selectionContents)
  }

  // Keyup event
  const slectData = (e) => {
    var data = getInputSelection(e)
    console.log(data)
  }

  const handleChange = (e) => {
    setCode(e)
    setCount(e.length)

  }
  const textWalker = (node, callback) => {
    const nodes = [node];
    while (nodes.length > 0) {
      node = nodes.shift();
      const children = [...node.childNodes];
      for (let i = 0; i < children.length; i++) {
        var child = children[i];
        if (child.nodeType === HTMLElement.TEXT_NODE)
          callback(child);
        else
          nodes.push(child);
      }
    }
  };

  // This will run a callback for each text node matching a given regexp pattern
  // The callback function can return an array of elements and strings.
  // The callback return value will be constructed in DOM
  const textSplit = (source, regexp, callback) => {
    textWalker(source, function (node) {
      let text = node.nodeValue;

      if (!regexp.test(text)) {
        return;
      }

      const out = callback(regexp, text);

      if (!(out instanceof Array)) {
        node.nodeValue = "" + out;
      }
      else {
        let nnode = out.shift();

        if (nnode instanceof HTMLElement || nnode.nodeType === HTMLElement.TEXT_NODE) {
          // Doesn't work with text nodes yet: node.insertAdjacentElement("afterend", nnode);
          node.parentNode.insertBefore(nnode, node);
          node.parentNode.removeChild(node);
          node = nnode;
        }
        else {
          node.textContent = "" + nnode;
        }

        while (out.length > 0) {
          nnode = out.shift();

          if (!(nnode instanceof HTMLElement) && nnode.nodeType !== HTMLElement.TEXT_NODE) {
            nnode = document.createTextNode("" + nnode);
          }
          // Doesn't work with text nodes yet: node.insertAdjacentElement("afterend", nnode);
          node.parentNode.insertBefore(nnode, node);
          node.parentNode.insertBefore(node, nnode);

          node = nnode;
        }
      }
    });
  };

  // setInterval(() => {
  //   Slider();
  // }, 20000);
  useEffect(() => {
    // setInterval(() => {
    //   Slider();
    // }, 1000);

    // Slider();
  }, [])
  let commandData = [{
    'name': 'DATA',
    'color': 'blue',
    'style': 'bold'
  },
  {
    'name': 'data',
    'color': 'blue',
    'style': 'lighter'
  },

  {
    'name': 'MERGE',
    'color': 'blue',
    'style': 'lighter'
  },
  {
    'name': 'SQL',
    'color': 'green',
    'style': 'bold'
  },
  {
    'name': 'RUN',
    'color': 'red',
    'style': 'bold'
  },
  {
    'name': 'QUIT',
    'color': 'blue',
    'style': 'bold'
  },
  {
    'name': 'quit',
    'color': 'blue',
    'style': 'lighter'
  },
  {
    'name': 'MEANS',
    'color': 'blue',
    'style': 'bold'
  },
  {
    'name': 'PRINT',
    'color': 'blue',
    'style': 'bold'
  },
  {
    'name': '&',
    'color': 'Crimson',
    'style': 'Italic'
  },

  {
    'name': 'PRINT',
    'color': 'blue',
    'style': 'bold'
  }];

  const highligher = () => {


    const template = document.createElement("span");

    commandData.map((x) => {


      let value = x.name;
      // let syyles = x.style;
      template.style.color = x.color;
      template.style.fontWeight = x.style;
      // You could obviously simplify any of this how ever you want.eval(`${value}`)
      // /(Anil)  /(Anil)/g textSplit(document.querySelector("pre"), /(Anil)/g, function (regexp, text) 
      let strRegEx = '/' + '(' + value + ')' + '/' + 'g';
      textSplit(document.querySelector("pre"), eval(strRegEx), function (regexp, text) {
        const out = [];
        text.split(regexp).forEach((text, i) => {
          if (i % 2 === 0) {
            out.push(text);
            return;
          };

          const node = template.cloneNode(true);
          node.textContent = text;
          //  node.style.color = colors;
          out.push(node);
        });
        return out;
      });
    })

  }

  useEffect(() => {

    // commandData.filter(obj => obj.name == "David");
    highligher();
    // const template = document.createElement("span");
    // template.style.color = "red";
    // highligher("DATA", "blue");
    // highligher("Data", "blue");
    // highligher("SQL", "blue");
    // highligher("RUN", "blue");
    // highligher("QUIT", "blue");
    // highligher("MEANS", "yellow");
    // highligher("PRINT", "yellow");

    // SET
    // MERGE
    // IF
    // THEN
    // DO
    // END



    // You could obviously simplify any of this how ever you want.
    // textSplit(document.querySelector("pre"), /(Anil)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });
    // template.style.color = "yellow";
    // textSplit(document.querySelector("pre"), /(ANIL)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });
    // template.style.color = "yellow";

    // textSplit(document.querySelector("pre"), /(SriRam)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });

    // template.style.color = "blue";

    // textSplit(document.querySelector("pre"), /(Abhishek)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });

    // template.style.color = "black";

    // textSplit(document.querySelector("pre"), /(Abhishek)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });
    // template.style.color = "green";

    // textSplit(document.querySelector("pre"), /(Abhilash)/g, function (regexp, text) {
    //   const out = [];
    //   text.split(regexp).forEach((text, i) => {
    //     if (i % 2 === 0) {
    //       out.push(text);
    //       return;
    //     };

    //     const node = template.cloneNode(true);
    //     node.textContent = text;

    //     out.push(node);
    //   });
    //   return out;
    // });



  }, [code])
  const handlekeyup = (e) => {
    //const textarea = document.querySelector('textarea')
    const lineNumbers = document.querySelector('.line-numbers')
    const numberOfLines = e.target.value.split('\n').length

    lineNumbers.innerHTML = Array(numberOfLines)
      .fill('<span></span>')
      .join('')
    // if (e.targe.value === 13) {
    //   Slider();
    // }
    // var _preCollection = document.getElementsByTagName('pre');
    // var _html_data = _preCollection[0].innerText.trim()
    // var _html_text = _preCollection[0].innerHTML
    // if (_html_data === 'Anil') {
    //   _preCollection[0].style.color = "red"
    // } else {
    //   _preCollection[0].style.color = "yellow"
    // }





  }

  const setCursorPos = (e) => {
    const cursor_pos = code.length;
    if (typeof e != "undefined" && e !== null) {
      let s = e.props.selectionStart;
      let r = e.props.selectionEnd;
      let slected = e.props.value.substring(s, r);
      // setSelection(slected)
      return e.props.value.substring(s, r);
    }
    else {
      return '';
    }


    // e.setSelectionRange(cursor_pos , cursor_pos );
    // e.focus();
  }
  return (
    <div className="App">
      <div className="window">
        <div className="title-bar">
          <div className="title-buttons">

            <div className="title-button"></div>
            <div className="title-button"></div>
            <div className="title-button"></div>
            <div> counter {count} /10000 </div>
          </div>
        </div>
        <div className="editor_wrap">
          <div className="line-numbers">
            <span></span>
          </div>
          <Editor
            value={code}
            onClick={handleClick}
            className="textarea"
            // onValueChange={(code) => setCode(code)}
            onKeyUp={handlekeyup}
            onValueChange={handleChange}
            highlight={(code) => highlight(code, languages.js)}
            padding={10}
            style={{
              fontFamily: '"Fira code", "Fira Mono", monospace',
              fontSize: 12, width: "90%", border: "2px solid grey"
            }}
          //  ref={setCursorPos}
          />
        </div>


      </div>
      <div style={{ marginRight: "26em" }}>

        <button> Submit</button>
      </div>

    </div>

  );
}

export default Editors;
