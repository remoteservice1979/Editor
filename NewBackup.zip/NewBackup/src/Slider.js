function Slider() {

    var doc = document,
        docEl = document.documentElement,
        body = doc.body,
        win = window;

    var slider = doc.createElement('div'),
        sliderSize = doc.createElement('div'),
        controller = doc.createElement('div'),
        sliderContent = doc.createElement('iframe'),
        scale = 0.01,
        realScale = scale;

    slider.className = 'slider';
    sliderSize.className = 'slider__size';
    controller.className = 'slider__controller';

    sliderContent.className += 'slider__content';
    sliderContent.style.transformOrigin = '0 0';

    slider.appendChild(sliderSize);
    slider.appendChild(controller);
    slider.appendChild(sliderContent);
    body.appendChild(slider);

    var html = doc.documentElement.outerHTML
        .replace(/<script([\s\S]*?)>([\s\S]*?)<\/script>/gim, '');// Remove all scripts

    var script = '<script>var slider=document.querySelector(".slider"); slider.parentNode.removeChild(slider);<' + '/script>';
    /*function checkChildren(node){ if ( node.nodeValue ) { node.nodeValue = node.nodeValue.replace(/[a-z0-9]/gi,"\u2592"); return; } for ( var i = 0; i < node.childNodes.length; i++) { checkChildren(node.childNodes[i]); } } /* checkChildren(body); */

    html = html.replace('</body>', script + '</body>');

    // Must be appended to body to work.
    var iframeDoc = sliderContent.contentWindow.document;

    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();


    ////////////////////////////////////////

    function getDimensions() {
        var bodyWidth = body.clientWidth,
            bodyRatio = body.clientHeight / bodyWidth,
            winRatio = win.innerHeight / win.innerWidth;

        slider.style.width = (scale * 100) + '%';

        // Calculate the actual scale in case a max-width/min-width is set.
        realScale = slider.clientWidth / bodyWidth;

        sliderSize.style.paddingTop = (bodyRatio * 100) + '%';
        controller.style.paddingTop = (winRatio * 100) + '%';

        sliderContent.style.transform = 'scale(' + realScale + ')';
        sliderContent.style.width = (100 / realScale) + '%';
        sliderContent.style.height = (100 / realScale) + '%';
    }

    getDimensions();
    win.addEventListener('resize', getDimensions);
    win.addEventListener('load', getDimensions);

    ////////////////////////////////////////
    // Track Scroll

    function trackScroll() {
        controller.style.transform = 'translate(' +
            ((win.pageXOffset * realScale)) + 'px, ' +
            ((win.pageYOffset * realScale)) + 'px)';
    }

    win.addEventListener('scroll', trackScroll);
}
export default Slider;
