import logo from './logo.svg';
import Editors from "./Editors";


import './App.css';

function App() {
  return (
    <>
      <Editors />
    </>
  );
}

export default App;
